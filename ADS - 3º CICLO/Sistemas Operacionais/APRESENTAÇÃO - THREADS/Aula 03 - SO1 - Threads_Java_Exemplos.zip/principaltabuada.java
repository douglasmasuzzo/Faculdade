public class principaltabuada {
	public static void main(String args[]) {
		tabuada n1 = new tabuada(1);
		tabuada n2 = new tabuada(2);
		tabuada n3 = new tabuada(3);
		tabuada n4 = new tabuada(4);
	
		System.out.println("=========================");
		System.out.println("Tabuada de N�meros Thread");
		System.out.println("=========================");
		
		n1.start();
		n2.start();
		n3.start();
		n4.start();
	}
}