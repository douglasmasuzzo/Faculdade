class tabuada extends Thread {
	private int numero;
	
	tabuada (int n) {
		numero = n;
	}

	public void run() {
		for (int i=0; i<=100; i++) {
			System.out.println(numero + " x " + i + " = " + numero*i);
		}
	}
}