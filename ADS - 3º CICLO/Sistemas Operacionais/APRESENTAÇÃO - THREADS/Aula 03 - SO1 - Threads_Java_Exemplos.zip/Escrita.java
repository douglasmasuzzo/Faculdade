public class Escrita extends Thread {
    private int i;
    public void run() {
        while (true)
               System.out.println("Numero: " + i++);
    }
}