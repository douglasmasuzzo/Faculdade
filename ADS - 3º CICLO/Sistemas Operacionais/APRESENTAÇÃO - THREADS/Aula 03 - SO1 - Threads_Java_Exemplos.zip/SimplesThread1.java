public class SimplesThread1 {
     public static void main(String[] args) {
          Escrita e = new Escrita();
          e.start();
     } 
}